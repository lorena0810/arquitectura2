from flask import Flask, render_template, request
from copy import deepcopy
import csv


app = Flask(__name__)

class datos:
    def __init__(self, fech ,tiem, temp, humed):
        self.fech = fech
        self.tiem = tiem
        self.temp = temp
        self.humed = humed

def clonacion(self):
        return deepcopy(self)

@app.route("/")
def index():
 return render_template('index.html')

@app.route('/log', methods=['GET'])
def log():
  #T=datetime.datetime.now()
  Tiempo = request.args.get('Tiempo')
  Temperatura = request.args.get('Temperatura')
  Humedad = request.args.get('Humedad') #if key doesn't exist, returns
  
 
  with open('09052019.csv','a') as datos:
    dat=csv.writer(datos)
    dat.writerow([Tiempo,Temperatura,Humedad])
  
  return render_template('index.html')
  
app.run(debug=True,host='0.0.0.0')